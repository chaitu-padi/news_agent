import streamlit as st
import pandas as pd
import time
from stream_simulator import generate_synthetic_firehose_batch
from ingestion import process_raw_payload
from agent import analyze_authorized_event

st.set_page_config(page_title="Authorized Stream Router", layout="wide", page_icon="🏦")

st.title("🏦 Enterprise Stream Triage & LLM Router")
st.markdown("Simulates a high-velocity data stream. Filters unauthorized media *before* triggering LLM compute.")

if "processed_log" not in st.session_state:
    st.session_state.processed_log = []
if "rejected_log" not in st.session_state:
    st.session_state.rejected_log = []

col1, col2 = st.columns([1, 3])

with col1:
    st.header("📡 Stream Controls")
    if st.button("Fetch Next Data Batch", type="primary"):
        with st.spinner("Consuming stream..."):
            raw_batch = generate_synthetic_firehose_batch()
            
            for raw_event in raw_batch:
                # 1. Ingestion & Validation
                news_obj = process_raw_payload(raw_event)
                
                # 2. Source Filtering Logic
                if not news_obj.is_authorized:
                    # Send to Dead-Letter/Rejected Queue (Bypasses LLM entirely)
                    st.session_state.rejected_log.append({
                        "Time": time.strftime("%H:%M:%S"),
                        "Source": news_obj.source_name,
                        "Headline": news_obj.headline,
                        "Reason": "Unauthorized Source - Dropped"
                    })
                else:
                    # 3. LLM Processing (Only for authorized data)
                    result = analyze_authorized_event(news_obj)
                    
                    st.session_state.processed_log.append({
                        "Time": time.strftime("%H:%M:%S"),
                        "Source": news_obj.source_name,
                        "Headline": news_obj.headline,
                        "Agent Action": result.get("output", "Routed via Tool")
                    })
        st.success(f"Processed batch of {len(raw_batch)} events.")

with col2:
    tab1, tab2 = st.tabs(["✅ Validated & Processed (LLM Active)", "🚫 Rejected Firehose (Compute Saved)"])
    
    with tab1:
        st.subheader("Authorized Pipeline Operations")
        if st.session_state.processed_log:
            st.dataframe(pd.DataFrame(st.session_state.processed_log), use_container_width=True)
        else:
            st.info("Awaiting authorized data stream...")
            
    with tab2:
        st.subheader("Dead-Letter Queue (Dropped at Ingestion)")
        st.markdown("*These events were blocked at the gateway, saving LLM tokens and inference compute.*")
        if st.session_state.rejected_log:
            st.dataframe(pd.DataFrame(st.session_state.rejected_log), use_container_width=True)
        else:
            st.info("No events rejected yet.")
