import os

LOCAL_LLM_BASE_URL = os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:8000/v1")
MODEL_NAME = os.getenv("MODEL_NAME", "meta-llama/Meta-Llama-3-70B-Instruct")

# Enterprise Source Governance
AUTHORIZED_SOURCES = [
    "Bloomberg Terminal",
    "Reuters Global",
    "Financial Times",
    "SEC Edgar API",
    "PR Newswire"
]

LOB_CONFIGS = {
    "GCIB": {"email": "gcib@bank.com", "teams": "webhook/gcib"},
    "Wealth_Management": {"email": "wealth@bank.com", "teams": "webhook/wealth"},
    "Global_Markets": {"email": "markets@bank.com", "teams": "webhook/markets"},
    "Compliance": {"email": "compliance@bank.com", "teams": "webhook/compliance"}
}
