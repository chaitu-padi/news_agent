from langchain_core.tools import tool
import config

@tool
def dispatch_lob_alert(target_lobs: list[str], severity: str, summary: str, impact_analysis: str, channels: list[str]) -> str:
    """Routes alerts to specific LOBs ('GCIB', 'Wealth_Management', 'Global_Markets', 'Compliance')."""
    log_results = []
    for lob in target_lobs:
        if lob in config.LOB_CONFIGS:
            log_results.append(f"Dispatched to {lob}")
    return " | ".join(log_results)
