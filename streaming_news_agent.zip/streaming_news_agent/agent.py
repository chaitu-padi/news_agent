from langchain_openai import ChatOpenAI
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
from tools import dispatch_lob_alert
from models import NormalizedNews
import config

llm = ChatOpenAI(
    base_url=config.LOCAL_LLM_BASE_URL,
    api_key="local",
    model=config.MODEL_NAME,
    temperature=0.0
)

tools = [dispatch_lob_alert]

system_instruction = """
You are the Enterprise Routing Agent. You only receive data from AUTHORIZED sources.
1. Determine if it is a MATERIAL EVENT.
2. If Material, identify WHICH Line of Business (LOB) needs to know (GCIB, Wealth_Management, Global_Markets, Compliance).
3. Formulate the impact analysis.
4. MUST Call `dispatch_lob_alert` with the affected LOBs.
If NOT material, output "Non-Material: [Reason]" and do not call tools.
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", system_instruction),
    ("human", "Headline: {headline}\nBody: {body}")
])

agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=False)

def analyze_authorized_event(news: NormalizedNews):
    try:
        return agent_executor.invoke({
            "headline": news.headline,
            "body": news.content
        })
    except Exception as e:
        return {"output": f"LLM Error: {str(e)}"}
